#pragma once
#include "Singleton.h"
#include "config.h"
class ScreenEffectManager : public Singleton<ScreenEffectManager>
{
};

