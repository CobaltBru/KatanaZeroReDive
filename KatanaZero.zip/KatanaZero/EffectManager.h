#pragma once
#include "Singleton.h"
class EffectManager : public Singleton<EffectManager>
{
};

